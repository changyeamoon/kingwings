const types = {
  ITEM_ADD: 'ITEM_ADD',
  ITEM_DELETE: 'ITEM_DELETE',
};

export default types;
