import React from 'react';

const Pdf = () => <div> PDF coming soon </div>;

export default Pdf;
